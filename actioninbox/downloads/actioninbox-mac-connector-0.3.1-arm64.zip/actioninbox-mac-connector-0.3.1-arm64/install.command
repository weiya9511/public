#!/bin/bash
set -euo pipefail

# Distributed alongside a signed, precompiled host. No Xcode/Node/Python is needed.
extension_id=""
app_path=""
library_root="$HOME/Library"
binary="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/ActionInboxBrowserCaptureHost"
host_bundle=""
[[ ! -d "$binary.app" ]] || host_bundle="$binary.app"
dry_run=false
while [[ $# -gt 0 ]]; do
  case "$1" in
    --extension-id) extension_id="${2:?缺少扩展 ID}"; shift 2 ;;
    --app) app_path="${2:?缺少 App 路径}"; shift 2 ;;
    --binary) binary="${2:?缺少连接组件路径}"; host_bundle=""; shift 2 ;;
    --host-bundle) host_bundle="${2:?缺少连接组件 App 路径}"; shift 2 ;;
    --library-root) library_root="${2:?缺少测试 Library 路径}"; shift 2 ;;
    --dry-run) dry_run=true; shift ;;
    *) echo "用法：$0 --extension-id <商店扩展ID> --app /绝对路径/知行待办.app [--dry-run]" >&2; exit 64 ;;
  esac
done
[[ "$extension_id" =~ ^[a-p]{32}$ ]] || { echo "需要明确的 32 位 Chrome 商店扩展 ID，不能使用通配来源。" >&2; exit 64; }
app_path="${app_path%/}"
[[ "$app_path" == /* && "$app_path" == *.app && -d "$app_path" && "$library_root" == /* ]] || { echo "请指定已安装知行待办 .app 的绝对路径。" >&2; exit 64; }
[[ "$app_path$library_root$binary$host_bundle" != *$'\n'* && "$app_path$library_root$binary$host_bundle" != *$'\r'* && "$app_path$library_root$binary$host_bundle" != *$'\t'* ]] || exit 64
[[ "$(/usr/bin/plutil -extract CFBundleIdentifier raw -o - "$app_path/Contents/Info.plist")" == "com.weiyawu.actioninbox" ]] || { echo "指定的 App 不是知行待办。" >&2; exit 64; }
if [[ -n "$host_bundle" ]]; then
  host_bundle="${host_bundle%/}"
  [[ "$(/usr/bin/plutil -extract CFBundleIdentifier raw -o - "$host_bundle/Contents/Info.plist")" == "com.weiyawu.actioninbox.browsercapturehost" && "$(/usr/bin/plutil -extract CFBundleExecutable raw -o - "$host_bundle/Contents/Info.plist")" == "ActionInboxBrowserCaptureHost" && -f "$host_bundle/Contents/embedded.provisionprofile" ]] || { echo "连接组件缺少正确标识或共享容器描述文件。" >&2; exit 65; }
  /usr/bin/codesign --verify --deep --strict -R '=anchor apple generic and certificate leaf[subject.OU] = "DJS7NHAFWV" and identifier "com.weiyawu.actioninbox.browsercapturehost"' "$host_bundle" || { echo "连接组件完整签名验证失败，未安装。" >&2; exit 65; }
  [[ -s "$host_bundle/Contents/CodeResources" ]] || { echo "连接组件缺少已装订的公证票据，未安装。" >&2; exit 65; }
  assessment="$(/usr/sbin/spctl --assess --type execute --verbose=2 "$host_bundle" 2>&1)" || { echo "连接组件未通过 macOS 分发安全验证，未安装。" >&2; exit 65; }
  [[ "$assessment" == *"source=Notarized Developer ID"* ]] || { echo "连接组件未通过 Developer ID 公证验证，未安装。" >&2; exit 65; }
  binary="$host_bundle/Contents/MacOS/ActionInboxBrowserCaptureHost"
fi
[[ -x "$binary" ]] || { echo "安装包缺少预编译连接组件。" >&2; exit 66; }
/usr/bin/codesign --verify --strict "$binary" || { echo "连接组件签名验证失败，未安装。" >&2; exit 65; }
/usr/bin/codesign --verify --deep --strict "$app_path" || { echo "Mac App 签名验证失败，未安装。" >&2; exit 65; }
architectures="$(/usr/bin/lipo -archs "$binary")"
machine="$(/usr/bin/uname -m)"
[[ " $architectures " == *" $machine "* ]] || { echo "连接组件不支持此 Mac 架构（$machine），请领取对应安装包。" >&2; exit 65; }

host_name="com.weiyawu.actioninbox.browser_capture"
install_dir="$library_root/Application Support/ActionInboxBrowserCaptureHost"
manifest_dir="$library_root/Application Support/Google/Chrome/NativeMessagingHosts"
manifest="$manifest_dir/$host_name.json"
config_dir="$library_root/Containers/com.weiyawu.actioninbox.browsercapturehost/Data/Library/Application Support/ActionInboxBrowserCaptureHost"
config="$config_dir/config.json"
installed_binary="$install_dir/ActionInboxBrowserCaptureHost"
new_host_dir=""
if [[ -n "$host_bundle" ]]; then
  # A fresh directory preserves the previously active bundle until the manifest switches.
  new_host_dir="$install_dir/host-$(date +%Y%m%d-%H%M%S)-$$"
  installed_binary="$new_host_dir/ActionInboxBrowserCaptureHost.app/Contents/MacOS/ActionInboxBrowserCaptureHost"
fi
if ! $dry_run; then
  mkdir -p "$install_dir" "$manifest_dir" "$config_dir"
  lock="$install_dir/.install-lock"
  mkdir "$lock" 2>/dev/null || { echo "已有安装进行中，请完成后重试。" >&2; exit 75; }
  trap 'rmdir "$lock"' EXIT
fi
origins=("chrome-extension://$extension_id/")
# Preserve explicitly allowed existing developer/store IDs. Never trust a wildcard.
for existing in "$manifest" "$config"; do
  if [[ -f "$existing" ]]; then
    if [[ "$existing" == "$manifest" ]]; then key="allowed_origins"; else key="allowedOrigins"; fi
    values="$(/usr/bin/plutil -extract "$key" json -o - "$existing")" || { echo "现有绑定配置无效，未覆盖。" >&2; exit 65; }
    values="$(printf '%s' "$values" | /usr/bin/sed 's@\\/@/@g')"
    while [[ "$values" =~ chrome-extension://([a-p]{32})/ ]]; do
      origin="chrome-extension://${BASH_REMATCH[1]}/"
      found=false
      for allowed in "${origins[@]}"; do [[ "$origin" != "$allowed" ]] || found=true; done
      $found || origins+=("$origin")
      values="${values/"$origin"/}"
    done
    remainder="$(printf '%s' "$values" | /usr/bin/tr -d '[],"[:space:]')"
    [[ -z "$remainder" ]] || { echo "现有来源白名单含无效或通配来源，未覆盖。" >&2; exit 65; }
  fi
done
json_escape() { local s="$1"; s="${s//\\/\\\\}"; s="${s//\"/\\\"}"; printf '%s' "$s"; }
origins_json=""
for origin in "${origins[@]}"; do
  [[ -z "$origins_json" ]] || origins_json+=","
  origins_json+="\"$origin\""
done
manifest_json="{\"name\":\"$host_name\",\"description\":\"知行待办浏览器连接组件\",\"path\":\"$(json_escape "$installed_binary")\",\"type\":\"stdio\",\"allowed_origins\":[$origins_json]}"
config_json="{\"applicationPath\":\"$(json_escape "$app_path")\",\"allowedOrigins\":[$origins_json]}"
if $dry_run; then
  printf '%s\n%s\n' "$manifest_json" "$config_json"
  exit 0
fi
completed=false
config_switched=false
binary_switched=false
bundle_created=false
cleanup() {
  if ! $completed; then
    if $config_switched; then
      if [[ -f "$backup/config.json" ]]; then cp "$backup/config.json" "$config"; else rm -f "$config"; fi
    fi
    if $bundle_created; then rm -rf "$new_host_dir";
    elif $binary_switched; then
      if [[ -f "$backup/ActionInboxBrowserCaptureHost" ]]; then cp "$backup/ActionInboxBrowserCaptureHost" "$installed_binary"; else rm -f "$installed_binary"; fi
    fi
  fi
  rm -f "$manifest.tmp.$$" "$config.tmp.$$" "$installed_binary.tmp.$$"
  rmdir "$lock"
}
trap cleanup EXIT
umask 077
backup="$install_dir/backup-$(date +%Y%m%d-%H%M%S)-$$"
mkdir "$backup"
[[ ! -f "$manifest" ]] || cp "$manifest" "$backup/manifest.json"
[[ ! -f "$config" ]] || cp "$config" "$backup/config.json"
[[ ! -f "$installed_binary" ]] || cp "$installed_binary" "$backup/ActionInboxBrowserCaptureHost"
if [[ -n "$host_bundle" ]]; then
  mkdir "$new_host_dir"
  bundle_created=true
  /usr/bin/ditto "$host_bundle" "$new_host_dir/ActionInboxBrowserCaptureHost.app"
  /usr/bin/codesign --verify --deep --strict "$new_host_dir/ActionInboxBrowserCaptureHost.app"
else
  cp "$binary" "$installed_binary.tmp.$$"
  chmod 755 "$installed_binary.tmp.$$"
fi
printf '%s\n' "$manifest_json" > "$manifest.tmp.$$"
printf '%s\n' "$config_json" > "$config.tmp.$$"
/usr/bin/plutil -extract name raw -o /dev/null "$manifest.tmp.$$"
/usr/bin/plutil -extract applicationPath raw -o /dev/null "$config.tmp.$$"
if [[ -z "$host_bundle" ]]; then
  mv "$installed_binary.tmp.$$" "$installed_binary"
  binary_switched=true
fi
mv "$config.tmp.$$" "$config"
config_switched=true
mv "$manifest.tmp.$$" "$manifest"
completed=true
printf '连接组件已绑定知行待办：%s\n扩展 ID：%s\n已有配置备份：%s\n' "$app_path" "$extension_id" "$backup"
